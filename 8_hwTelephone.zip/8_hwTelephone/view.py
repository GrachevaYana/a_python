def input_num():
    ask = int(input("1 - Добавить пользователя\n2 - Найти пользователя\n"
                    "3 - Изменить пользователя\n4 - Удалить пользователя\n"
                    "5 - Отсоритровать\n6 - Вывести всё\n7 - Сгенерировать справочник\n8 - Выйти\n"))
    return ask

def input_info():
    fio = input("Введи ФИО человека - ")
    birth = input("Введи дату рождения - ")
    tele = input("Введи телефон - ")
    info = f"{fio},{birth},{tele}\n"
    return info

def input_char():
    char = input("Введите характеристику - ")
    return char

def select_num():
    num = int(input("Выбери строчку  - "))
    return num

def select_sort():
    sort_num = int(input("1 - Отсортировать по ФИО\n2 - Отсортировать по дате рождения\n"
                    "3 - Отсортировать по телефону\n"))
    return sort_num

def input_count():
    return int(input("Введите кол-во строк для генерации - "))